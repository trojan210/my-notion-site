# PACE  Extensive Listening Record用プロンプト

> Bookmarks
> 

[BBC Learning English - 6 Minute English](https://www.bbc.co.uk/learningenglish/english/features/6-minute-english)

[](https://chatgpt.com/)

[Microsoft Copilot: Your everyday AI companion](https://copilot.microsoft.com/)

<aside>
<img src="https://www.notion.so/icons/book-closed_gray.svg" alt="https://www.notion.so/icons/book-closed_gray.svg" width="40px" /> スクリプトの欄に原稿をコピペすれば課題が終わるよ♡

---

According to the <Script> below, please make notes similar to the <example> using student level English.

<Script>

＜Example＞

What I read, watched, or listened to: 

6-Minute English (Episode: ‘For the Love of Languages’)

My notes (note form only, no full sentences, your own words, not copied from transcript):
・polyglots benefit from lots of advantages (‘poly’ means ‘many’)
・polyglots learn languages for sheer enjoyment (not because they have to)
・polyglots better at communicating with others
・linguists love studying them
・Mandela – talking to someone in their own language ‘speaks to their heart’
・speaking in another language = having a ‘second soul’
・good for brain - learning and repeating language patterns makes the brain more efficient (research with multilingual children)
・polyglot literally means ‘many tongues’

Opinion (note form only, no full sentences, your own words, reasons included)
・would like to be a polyglot (but perhaps need to be born with it) – would be helpful in life & open up future job chances
・agree with brain benefits
・maybe not necessary in the days of Google Translate & DeepL?

New vocabulary and Definition:
・polyglot (n):someone who speaks many languages 
・identify with (v):feel that you are similar or closely connected to something
・sheer (adj):nothing except; used to emphasise how strong, pure or powerful a feeling is

Questions / further research (optional):
・Techniques to become a polyglot? Or just born with it?
・Any disadvantages?

</aside>